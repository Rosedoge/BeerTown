package com.rosecreates.beertownfb;

public class Comment {
}
